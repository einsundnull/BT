package com.notorein.bt;

import junit.framework.TestCase;

public class CustomClockTest extends TestCase {

}