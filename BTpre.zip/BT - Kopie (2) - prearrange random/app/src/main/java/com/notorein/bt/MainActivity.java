package com.notorein.bt;

import static android.view.View.VISIBLE;
import static com.notorein.bt.RepeatStorage.shownIndexesPosition;
import static com.notorein.bt.SessionParameters.MAX_PRESENT_DEFAULT;
import static com.notorein.bt.SessionParameters.allowCountingMatches;
import static com.notorein.bt.SessionParameters.countDownIntervalDefault;
import static com.notorein.bt.SessionParameters.increasedCounter;
import static com.notorein.bt.SessionParameters.maxPresentations;
import static com.notorein.bt.SessionParameters.nBack;
import static com.notorein.bt.SessionParameters.positionIsClicked;
import static com.notorein.bt.SessionParameters.presentations;
import static com.notorein.bt.SessionParameters.randomIndexIncreaseFactor;
import static com.notorein.bt.SessionParameters.speedPercentage;
import static com.notorein.bt.SessionParameters.trialCounter;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import java.util.ArrayList;
import java.util.Random;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {



    public static ConstraintLayout rectContainer;

    ArrayList<Button> btns = new ArrayList<>();
    private int lastPosition = 0;
    private int lastAudio = 0;
    private int lastColor = 0;
    private int counter = 3;
    private static int shownAndCounted = 0;
    private static CountDownTimer ct;
    private static CountDownTimer cClock;
    private int screenOrientation;
    private RepeatStorage storage;
    private Button btnPosition;
    private Button btnSound;
    private Button btnNBackLevel;
    private Button btnIncrease;
    private Button btnSpeed;
//    private int displayWidth;
//    private int displayHeight;
    private ConstraintLayout mainLayout;
    private ConstraintLayout main_menu;

    private EditText textViewNBackLevel;
    private EditText textViewRndIncrease;
    private EditText textViewSpeed;

    private TextView textViewMiddle;
    public  TextView lbl_n_back_Info_Pause;
    public  TextView lbl_n_Back;
    public  TextView infoTxt;

    private static Boolean lastClickRight;
    private static Boolean lastMatch;
    private static boolean endTrialByTime;
    private static boolean paused;
    private static boolean ctIsRunning;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);

        setContentView(R.layout.activity_main);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        screenOrientation = this.getResources().getConfiguration().orientation - 1;
        setOrientationListener();


        storage = new RepeatStorage();
        rectContainer = (ConstraintLayout) findViewById(R.id.rectContainer);
        getViews();
        mainLayout.setBackgroundColor(Color.BLACK);

        for (int i = 0; i < btns.size(); i++) {
            btns.get(i).setVisibility(View.INVISIBLE);
            ConstraintLayout.LayoutParams paramsWidth = (ConstraintLayout.LayoutParams) btns.get(i).getLayoutParams();
            paramsWidth.width = 150;
            btns.get(i).setLayoutParams(paramsWidth);
            ConstraintLayout.LayoutParams paramsHeight = (ConstraintLayout.LayoutParams) btns.get(i).getLayoutParams();
            paramsHeight.height = 150;
            btns.get(i).setLayoutParams(paramsHeight);
        }


        btns.get(4).setVisibility(View.INVISIBLE);

        setTextsToView();
        setOnClickListeners();


        textViewMiddle.setOnClickListener(this);
        if (!ctIsRunning) {
            startTrial();
        }
    }



    private synchronized void setTextsToView() {
//        textViewRndIncrease.setText("" + randomIndexIncreaseFactor);
//        textViewNBackLevel.setText("" + nBack);
//        textViewSpeed.setText("" + speedPercentage);

        btnPosition.setText("Position");
        btnSound.setText("Sound");
//        btnNBackLevel.setText("NBack");
//        btnIncrease.setText("RND");
//        btnSpeed.setText("Speed");
        textViewMiddle.setText("+");
    }

    private synchronized void getViews() {
        mainLayout = (ConstraintLayout) findViewById(R.id.mainLayout);
        main_menu = (ConstraintLayout) findViewById(R.id.main_menu);
        btns.add(findViewById(R.id.button0));
        btns.add(findViewById(R.id.button1));
        btns.add(findViewById(R.id.button2));
        btns.add(findViewById(R.id.button3));
        btns.add(findViewById(R.id.button4));
        btns.add(findViewById(R.id.button5));
        btns.add(findViewById(R.id.button6));
        btns.add(findViewById(R.id.button7));
        btns.add(findViewById(R.id.button8));

        btnPosition = (Button) findViewById(R.id.buttonPosition);
        btnSound = (Button) findViewById(R.id.buttonSound);
        textViewMiddle = (TextView) findViewById(R.id.textViewMiddle);
        infoTxt = findViewById(R.id.infoTxt);

        
        btnNBackLevel = (Button) findViewById(R.id.btnNBackLevel);
        btnIncrease = (Button) findViewById(R.id.btnIncrease);
        btnSpeed = (Button) findViewById(R.id.btnSpeed);

        textViewRndIncrease = (EditText) findViewById(R.id.textViewRndIncrease);
        textViewNBackLevel = (EditText) findViewById(R.id.textViewNBackLevel);
        textViewSpeed = (EditText) findViewById(R.id.textViewDuration);
    }


    private synchronized void setOrientationListener() {
        try {
            ct.cancel();
            ctIsRunning = false;
            if (screenOrientation != this.getResources().getConfiguration().orientation) {
                screenOrientation = this.getResources().getConfiguration().orientation;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

//    private void getDisplayMetrics() {
//        DisplayMetrics displayMetrics = new DisplayMetrics();
//        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
//        displayHeight = displayMetrics.heightPixels;
//        displayWidth = displayMetrics.widthPixels;
//    }

    private synchronized void startTrial() {
        ctIsRunning = true;
        paused = false;
        counter = 3;
        for (int n = 0; n < btns.size(); n++) {
            btns.get(n).setVisibility(View.INVISIBLE);
        }
        SessionParameters.maxPresentations = MAX_PRESENT_DEFAULT + SessionParameters.nBack;
        shownIndexesPosition = precalculateRandom();
        shownIndexesPosition = increaseNumberOfMatches(shownIndexesPosition);
        RepeatStorage.matchesPosition = precalculateMatches(shownIndexesPosition, nBack);
        ct = new CountDownTimer(SessionParameters.durationSession, (long) SessionParameters.countDownInterval) {
            public void onTick(long millisUntilFinished) {
                if (!paused) {
                    if (presentations == maxPresentations) {
                        endTrialByTime = true;
                        counter = 2;
                    }
                    if (presentations < maxPresentations) {
                        if (counter == 1) {
                            presentations++;
                        }
                        if (counter == 2) {
                            if (presentations > nBack) {
                                allowCountingMatches = true;
                                shownAndCounted++;
                            }
                            setInfoText();
                            processOutCome();
                            if (endTrialByTime) {
                                endTrialByTime = false;
                                counter = 1;
                                onFinish();


                            }
                            btns.get(shownIndexesPosition.get(presentations)).setVisibility(VISIBLE);
                        } else if (counter == 3) {
                            if (SessionParameters.includePosition) {
                                btns.get(shownIndexesPosition.get(presentations)).setVisibility(View.INVISIBLE);
                            }
                            counter = 0;
                        }
                        counter++;
                    }
                }
            }

            public void onFinish() {
//                this.cancel();
                SessionParameters.trialCounter++;
                if(trialCounter > SessionParameters.trialsMax){
                    trialCounter = 0;
                    SessionParameters.endSession = true;
                }
                int increase = 0;

                if (SessionParameters.includePosition) {
                    increase = RepeatStorage.decideWhetherToInOrDecreaseNBackLevel(SessionParameters.percentageClickedRightPosition);
                }
                if (SessionParameters.includeAudio && increase > -1) {
                    increase = RepeatStorage.decideWhetherToInOrDecreaseNBackLevel(SessionParameters.percentageClickedRightAudio);
                }
                if (SessionParameters.includeAudio && increase > -1) {
                    increase = RepeatStorage.decideWhetherToInOrDecreaseNBackLevel(SessionParameters.percentageClickedRightAudio);
                }
                RepeatStorage.inOrDecreaseNBackLevel(increase);
                ctIsRunning = false;
                paused = false;
                counter = 1;
                resetTrial();
            }

        }.start();
    }

    @SuppressLint("SetTextI18n")
    private synchronized void setInfoText() {
        StringBuilder text = new StringBuilder();
        for (int i = presentations; i < presentations + nBack; i++) {
            try {
                text.append(shownIndexesPosition.get(i)).append(" ");
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        try {
            infoTxt.setText("NB: " + nBack + "\nInc: " + SessionParameters.increasedCounter + "\n"
                    + text + "\nShw: " + presentations + "\nShwCnt: " + shownAndCounted + "\nMtch: "
                    + SessionParameters.counterMatchesPosition + "\nRght: "
                    + SessionParameters.counterClickedRightPosition + "\nPctR: "
                    + SessionParameters.percentageClickedRightPosition);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    private synchronized ArrayList<Integer> precalculateRandom() {
        ArrayList<Integer> precalculatedIndexes = new ArrayList<>();
        for (int i = 0; i <= maxPresentations; i++) {
            int rnd = new Random().nextInt(9);
            if (SessionParameters.excludeFourFromRandomIndex) {
                while (rnd == 4) {
                    rnd = new Random().nextInt(9);
                }
            }
            precalculatedIndexes.add(rnd);
        }
        return precalculatedIndexes;
    }

    public synchronized ArrayList<Integer> increaseNumberOfMatches(ArrayList<Integer> randomIndexes) {
        ArrayList<Integer> temp = new ArrayList<>();
        int size = randomIndexes.size();
        int last;
        int rnd;
        for (int i = 0; i < size; i++) {
            rnd = new Random().nextInt(SessionParameters.randomIndexIncreaseFactor);
            if (rnd == 0) {
                try {
                    last = randomIndexes.get(i - nBack);
                    increasedCounter++;
                } catch (Exception e) {
                    last = randomIndexes.get(i);
                }
            } else {
                last = randomIndexes.get(i);
            }
            temp.add(last);
        }
        return temp;
    }


    private synchronized ArrayList<Boolean> precalculateMatches(ArrayList<Integer> precalculatedIndexes, int nBack) {
        ArrayList<Boolean> matches = new ArrayList<>();
        int shownCounter = 0;
        boolean match;
        int previous;
        int last;
        for (int i = 0; i <= maxPresentations; i++) {
            match = false;
            last = precalculatedIndexes.get(i);
            if (shownCounter >= nBack) {
                previous = precalculatedIndexes.get(i - nBack);
                if (last == previous) {
                    match = true;
                    SessionParameters.counterMatchesPosition++;
                }
            }
            matches.add(match);
            shownCounter++;
        }
        return matches;
    }


    private synchronized void processOutCome() {
        if (SessionParameters.includePosition) {
            RepeatStorage.clickedPositionRight = storage.storeShownIndexes(RepeatStorage.matchesPosition, RepeatStorage.clickedPositionRight, btnPosition, presentations, nBack, positionIsClicked, allowCountingMatches);
            try {
                lastClickRight = RepeatStorage.clickedPositionRight.get(RepeatStorage.clickedPositionRight.size() - 1);
                if (lastClickRight) {
                    SessionParameters.counterClickedRightPosition++;
                }
                double tempShownCounter = shownAndCounted;
                double tempCounterClickedRightPosition = SessionParameters.counterClickedRightPosition;
                SessionParameters.percentageClickedRightPosition = tempCounterClickedRightPosition / tempShownCounter;
            } catch (Exception e) {
                e.printStackTrace();
            }
            SessionParameters.positionIsClicked = false;
            SessionParameters.positionIsRight = false;
        }
//        if (SessionParameters.includeAudio) {
//            lastAudio = new Random().nextInt(9);
//            lastAudio = createRandomIndex(lastAudio);
//            lastAudio = increaseNumberOfMatches(lastAudio);
//            RepeatStorage.listOfClickAndMatchAudio = storage.storeShownIndexes(RepeatStorage.listOfClickAndMatchAudio, RepeatStorage.clickedAudioRight, RepeatStorage.matchesAudio, RepeatStorage.shownIndexesAudio, btnSound, btns.get(tempLastAudio), tempLastAudio, SessionParameters.nBack, SessionParameters.audioIsClicked, allowCountingMatches);
////                        btns.get(tempLastSound).setVisibility(View.INVISIBLE);
//            SessionParameters.audioIsClicked = false;
//            SessionParameters.audioIsRight = false;
//        }
//        if (SessionParameters.includeColor) {
//            lastColor = createRandomIndex(lastColor);
//            lastColor = increaseNumberOfMatches(lastColor);
//            RepeatStorage.listOfClickAndMatchColor = storage.storeShownIndexes(RepeatStorage.listOfClickAndMatchColor, RepeatStorage.clickedColorRight, RepeatStorage.matchesColor, RepeatStorage.shownIndexesColor, btnSound, btns.get(tempLastColor), tempLastColor, SessionParameters.nBack, SessionParameters.colorIsClicked, allowCountingMatches);
////                        btns.get(tempLastColor).setVisibility(View.INVISIBLE);
//            SessionParameters.colorIsClicked = false;
//            SessionParameters.colorIsRight = false;
//        }
        for (int i = 0; i < btns.size(); i++) {
            btns.get(i).setBackgroundColor(Color.BLUE);
        }
    }

    private void setOnClickListeners() {
        btnPosition.setOnClickListener(this);
        btnSound.setOnClickListener(this);
//        btnIncrease.setOnClickListener(this);
//        btnNBackLevel.setOnClickListener(this);
//        btnSpeed.setOnClickListener(this);
    }
    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.buttonPosition) {
            SessionParameters.positionIsClicked = true;
        }
        if (v.getId() == R.id.buttonSound) {
            SessionParameters.audioIsClicked = true;
            if (!ctIsRunning) {
                startTrial();
            } else {
                ct.onFinish();
                ct.cancel();
            }
        }
        if (v.getId() == R.id.textViewMiddle) {

            Intent intent = new Intent(this, SettingsActivity.class);
            startActivity(intent);
        }
        if (v.getId() == R.id.btnNBackLevel) {
            try {
                nBack = Integer.parseInt(textViewNBackLevel.getText().toString());
            } catch (Exception e){
                nBack = 1;
            }
            setInfoText();
        }
        if (v.getId() == R.id.btnIncrease) {
            try {
                randomIndexIncreaseFactor = Integer.parseInt(textViewRndIncrease.getText().toString());
            } catch (Exception e){
                randomIndexIncreaseFactor = 6;
            }
            setInfoText();
        }

        if (v.getId() == R.id.btnSpeed) {
            try {
                speedPercentage = Double.parseDouble(textViewSpeed.getText().toString());
            } catch (Exception e){
                speedPercentage = 1;
            }
            SessionParameters.countDownInterval = countDownIntervalDefault * speedPercentage;
            setInfoText();
        }

    }

    private synchronized static void resetTrial() {
        presentations = 0;
        shownAndCounted = 0;
        SessionParameters.counterClickedRightPosition = 0;
        SessionParameters.counterMatchesPosition = 0;
        SessionParameters.increasedCounter = 0;
        SessionParameters.percentageClickedRightPosition = 1;
        SessionParameters.allowCountingMatches = false;
    }







}