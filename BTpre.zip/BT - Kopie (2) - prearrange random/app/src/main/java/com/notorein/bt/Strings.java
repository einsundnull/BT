package com.notorein.bt;

import java.text.BreakIterator;

public class Strings {

    public static String manualText;
    public static BreakIterator lbl_n_back_Info_Pause;
}
