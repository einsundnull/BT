package com.notorein.bt;

public class SessionParameters {


    public static boolean positionIsClicked;
    public static boolean audioIsClicked;
    public static boolean colorIsClicked;

    public static boolean positionIsRight;
    public static boolean audioIsRight;
    public static boolean colorIsRight;

    public static boolean includePosition = true;
    public static boolean includeAudio = false;
    public static boolean includeColor = false;

    public static boolean excludeFourFromRandomIndex = true;


    public static int presentations = 0;
    public static int trialCounter = 0;
    public static  int trialsMax = 10;
    public static int sessionCounter = 0;
    public static double percentageAll;
    public static double percentageClickedRightPosition;
    public static double percentageClickedRightAudio;
    public static double percentageClickedRightColor;
    public static int counterMatchesPosition = 0;
    public static int counterClickedRightPosition = 0;
    public static boolean allowCountingMatches;

    public static double overallPercentage;
    public static int includedModes;
    public static Modes mode;
    public static int increasedCounter = 0;
    public static int squareSize = 150;
    public static boolean endSession;

    private static String manualText = "Press  ";
    public static String user;

    public static String confirmMatchAudio = "L";
    public static String confirmMatchPosition = "S";
    public static String confirmMatchColor = "D";
    public static int randomIndexLimit = 9;

    public static double decreaseThreshold = 0.75;
    public static double increaseThreshold = 0.85;
    //public static double increaseThreshold = 0.76;
    public static final double MAX_PRESENT_DEFAULT = 4;
    public static double maxPresentations = 40;
    public static int nBack = 1;
    public static double speedPercentage = 1;
    public static final double countDownIntervalDefault = 1333;
    public static double countDownInterval = countDownIntervalDefault * speedPercentage;
    public static int durationSession = 1000000;
    public static int randomIndexIncreaseFactor = 6;

//    public static int repeatTime = 950;

    public static int indexCreateCounter = 0;
//    public static int indexPlayAudio;
//    public static int indexShowPosition;
//    public static int indexShowColor;
//    public static int lengthTime;

    public static int indexLang;
    public static boolean durationTraining;
    public static String dateOfLastUse;
    private static int tempIndexLang;


    //    public static int randomIndexIncreaseFactor = 60 ;
    private static int randomIndexIncreaseFactorDurationMode = 30;

//    private static double rectSize = 200;
//    public static double rootIIHeight;
//    public static double rootIIWidth;
//    private static double fontSize = 125;
//    private static String fontType;
//    private double height;
//    private static double width;
}
