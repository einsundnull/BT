package com.notorein.bt;

import static com.notorein.bt.SessionParameters.MAX_PRESENT_DEFAULT;
import static com.notorein.bt.SessionParameters.maxPresentations;

import android.graphics.Color;
import android.widget.Button;

import java.util.ArrayList;

public class RepeatStorage {

    public static ArrayList<Integer> shownIndexesPosition = new ArrayList<>();
    public static ArrayList<Integer> shownIndexesAudio = new ArrayList<>();
    public static ArrayList<Integer> shownIndexesColor = new ArrayList<>();

//    public static ArrayList<ArrayList<Boolean>> listOfClickAndMatchPosition = new ArrayList<>();
//    public static ArrayList<ArrayList<Boolean>> listOfClickAndMatchAudio = new ArrayList<>();
//    public static ArrayList<ArrayList<Boolean>> listOfClickAndMatchColor = new ArrayList<>();

    public static ArrayList<Boolean> matchesPosition = new ArrayList<>();
    public static ArrayList<Boolean> matchesAudio = new ArrayList<>();
    public static ArrayList<Boolean> matchesColor = new ArrayList<>();

    public static ArrayList<Boolean> clickedPositionRight = new ArrayList<>();
    public static ArrayList<Boolean> clickedAudioRight = new ArrayList<>();
    public static ArrayList<Boolean> clickedColorRight = new ArrayList<>();

    public static int shownCounter = 0;

    public ArrayList<Boolean> storeShownIndexes(ArrayList<Boolean> matches, ArrayList<Boolean> clickedRight, Button btnClick, int presentations, int nBack, boolean clicked, boolean allowCountingMatches) {
        if (allowCountingMatches) {
            boolean match = false;
            try {
                match = matches.get(presentations-1);
                if (match) {
                    if (clicked) {
                        btnClick.setBackgroundColor(Color.GREEN);
                        btnClick.setText("right yes");
                        match = true;
                    } else {
                        btnClick.setBackgroundColor(Color.RED);
                        btnClick.setText("false no");
                        match = false;
                    }
                } else {
                    if (clicked) {
                        btnClick.setBackgroundColor(Color.MAGENTA);
                        btnClick.setText("false yes");
                        match = false;

                    } else {
                        btnClick.setBackgroundColor(Color.CYAN);
                        btnClick.setText("right no");
                        match = true;
                    }
                }
            } catch (Exception e) {
                match = true;
            }
            clickedRight.add(match);
        }
        return clickedRight;
    }


    public static int decideWhetherToInOrDecreaseNBackLevel(double percentage) {
        int increase = 1;
        if (percentage < SessionParameters.increaseThreshold && percentage >= SessionParameters.decreaseThreshold) {
            increase = 0;
        }
        if (percentage < SessionParameters.decreaseThreshold) {
            increase = -1;
        }
        return increase;
    }

    public static void inOrDecreaseNBackLevel(int increase) {
        if (increase == -1) {
            SessionParameters.nBack--;
        }
        if (increase == 1) {
            SessionParameters.nBack++;
        }
        if (SessionParameters.nBack < 1) {
            SessionParameters.nBack = 1;
        }
        maxPresentations = MAX_PRESENT_DEFAULT + SessionParameters.nBack;
    }

}
